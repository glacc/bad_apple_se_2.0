﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HuffmanEnc
{
    class Huffman
    {
        struct Branch
        {
            public byte OrigByte;
            public int Frequency;
            public int LeftChild;
            public int RightChild;

            public Branch(byte InitByte, int InitFreq = 0, int InitLeft = -1, int InitRight = -1)
            {
                OrigByte = InitByte;
                Frequency = InitFreq;
                LeftChild = InitLeft;
                RightChild = InitRight;
            }
        }

        struct HuffmanCode
        {
            public int[] Code;
            public HuffmanCode(int Leng)
            {
                Code = new int[Leng];
            }
        }

        const string HeaderFlag = "GlaccHuffmanEnc";

        static public byte[] Encode(byte[] OriginalData)
        {
            int[] FreqTable = new int[256];

            //Frequency calculation
            int DataPtr = 0;
            while (DataPtr < OriginalData.Length)
            {
                FreqTable[OriginalData[DataPtr++]]++;
            }

            //Initialize branch table
            List<Branch> BranchTable = new List<Branch>();

            DataPtr = 0;
            while (DataPtr < 256)
            {
                if (FreqTable[DataPtr] > 0)
                {
                    BranchTable.Add(new Branch((byte)DataPtr, FreqTable[DataPtr]));
                }
                DataPtr++;
            }

            if (BranchTable.Count <= 1)
                throw new Exception("There is only one joint generated via the selected file.");

            //Generate huffman tree
            List<Branch> ExcludedBranch = new List<Branch>();

            bool Fin = false;

            while (true)
            {
                Branch[] MinBranch = { new Branch(0, int.MaxValue), new Branch(0, int.MaxValue) };
                int[] MinIndex = { -1, -1 };

                if (BranchTable.Count - ExcludedBranch.Count >= 2)
                {
                    int i = 0;
                    while (i < 2)
                    {
                        int j = 0;
                        while (j < BranchTable.Count)
                        {
                            Branch ThisBranch = BranchTable[j];
                            if (!ExcludedBranch.Contains(ThisBranch) && ThisBranch.Frequency < MinBranch[i].Frequency)
                            {
                                MinBranch[i] = ThisBranch;
                                MinIndex[i] = j;
                            }
                            j++;
                        }

                        ExcludedBranch.Add(MinBranch[i]);

                        i++;
                    }
                }
                else
                {
                    Fin = true;
                    break;
                }

                if (!Fin)
                {
                    Branch Joint = new Branch(0, MinBranch[0].Frequency + MinBranch[1].Frequency, MinIndex[0], MinIndex[1]);
                    BranchTable.Add(Joint);
                }
                else
                {
                    break;
                }
            }

            //Debug
            int k = 0;
            while (k < BranchTable.Count)
            {
                Branch ThisBranch = BranchTable[k];
#if DEBUG
                Console.WriteLine($"Branch {k}:\n    Byte: {ThisBranch.OrigByte}\n    Freq: {ThisBranch.Frequency}\n    LeftChild: {ThisBranch.LeftChild}\n    RightChild: {ThisBranch.RightChild}");
#endif
                k++;
            }

            //Generate code of each character
            Branch Root = BranchTable[BranchTable.Count - 1];
            List<Branch> BranchStack = new List<Branch> { Root };
            List<byte> LRFinished = new List<byte>{ 0 };

            HuffmanCode[] CodeArray = new HuffmanCode[256];

            while (true)
            {
                if (LRFinished[0] >= 2) break;

                Branch CurBranch = BranchStack[BranchStack.Count - 1];

                if (CurBranch.LeftChild != -1)
                {
                    if (LRFinished[LRFinished.Count - 1] < 2)
                    {
                        BranchStack.Add(BranchTable[LRFinished[LRFinished.Count - 1] < 1 ? CurBranch.LeftChild : CurBranch.RightChild]);
                        LRFinished.Add(0);
                    }
                    else
                    {
                        BranchStack.RemoveAt(BranchStack.Count - 1);
                        LRFinished.RemoveAt(LRFinished.Count - 1);
                        LRFinished[LRFinished.Count - 1]++;
                    }
                }
                else
                {
                    HuffmanCode ThisCode = new HuffmanCode(LRFinished.Count - 1);

#if DEBUG
                    Console.WriteLine($"{((char)CurBranch.OrigByte).ToString()}: ");
#endif

                    int i = 0;
                    while (i < LRFinished.Count - 1)
                    {
                        ThisCode.Code[i] = LRFinished[i] < 1 ? 0 : 1;
#if DEBUG
                        Console.WriteLine($"    {ThisCode.Code[i]}");
#endif
                        i++;
                    }

                    CodeArray[CurBranch.OrigByte] = ThisCode;

                    BranchStack.RemoveAt(BranchStack.Count - 1);
                    LRFinished.RemoveAt(LRFinished.Count - 1);
                    LRFinished[LRFinished.Count - 1]++;
                }
            }

            //Calculate final size
            long FinalSize = 0;

            DataPtr = 0;
            while (DataPtr < 256)
            {
                if (FreqTable[DataPtr] > 0)
                    FinalSize += CodeArray[DataPtr].Code.Length * FreqTable[DataPtr];

                DataPtr++;
            }

            //Write compressed data
            byte[] CompressedData = new byte[(int)Math.Ceiling(FinalSize / 8.0)];

            DataPtr = 0;
            long BitCount = 0;
            while (DataPtr < OriginalData.Length)
            {
                byte ThisChar = OriginalData[DataPtr];
                int CurLength = CodeArray[ThisChar].Code.Length;

                int i = 0;
                while (i < CurLength)
                {
                    if (CodeArray[ThisChar].Code[i] != 0)
                        CompressedData[BitCount / 8] |= (byte)(0x80 >> (int)(BitCount % 8));

                    BitCount++;
                    i++;
                }
                DataPtr++;
            }

            //Output
            long FinalOutputSize =
                HeaderFlag.Length +                   //Header
                4 +                                   //Branch count
                BranchTable.Count * (1 + 4 + 4) +     //Branch table
                8 +                                   //Bit count
                4 +                                   //Original size
                CompressedData.Length;

            byte[] Output = new byte[FinalOutputSize];

            int Offset = 0;

            //Write header
            byte[] HeaderByteData = System.Text.Encoding.Default.GetBytes(HeaderFlag);

            DataPtr = 0;
            while (DataPtr < HeaderByteData.Length)
                Output[Offset++] = HeaderByteData[DataPtr++];

            //Write branch count
            void WriteNumberArr(byte[] ByteArr)
            {
                int i = 0;
                while (i < ByteArr.Length)
                    Output[Offset++] = ByteArr[i++];
            }

            WriteNumberArr(BitConverter.GetBytes(BranchTable.Count));

            //Write branch table
            DataPtr = 0;
            while (DataPtr < BranchTable.Count)
            {
                //OrigByte
                Output[Offset++] = BranchTable[DataPtr].OrigByte;

                //LeftChild
                WriteNumberArr(BitConverter.GetBytes(BranchTable[DataPtr].LeftChild));

                //RightChild
                WriteNumberArr(BitConverter.GetBytes(BranchTable[DataPtr].RightChild));

                DataPtr++;
            }

            //Bit count
            WriteNumberArr(BitConverter.GetBytes(FinalSize));
            //Original file size
            WriteNumberArr(BitConverter.GetBytes(OriginalData.Length));

            DataPtr = 0;
            while (DataPtr < CompressedData.Length)
                Output[Offset++] = CompressedData[DataPtr++];

            return Output;
        }


        static public byte[] Decode(byte[] OriginalData)
        {
            string Header = System.Text.Encoding.Default.GetString(OriginalData, 0, HeaderFlag.Length);
            if (Header != HeaderFlag)
                throw new Exception("This is not .glh file.");

            List<Branch> BranchTable = new List<Branch>();

            int BranchCount = BitConverter.ToInt32(OriginalData, HeaderFlag.Length);

            int DataPtr = HeaderFlag.Length + 4;

            int i = 0;
            while (i < BranchCount)
            {
                byte OrigByte = OriginalData[DataPtr];
                int LeftChild = BitConverter.ToInt32(OriginalData, DataPtr + 1);
                int RightChild = BitConverter.ToInt32(OriginalData, DataPtr + 5);

#if DEBUG
                Console.WriteLine($"Branch {i}:\n    Byte: {OrigByte}\n    LeftChild: {LeftChild}\n    RightChild: {RightChild}");
#endif

                BranchTable.Add(new Branch(OrigByte, default, LeftChild, RightChild));

                DataPtr += 9;
                i++;
            }

            long FileSize = BitConverter.ToInt64(OriginalData, DataPtr);
            int OriginalSize = BitConverter.ToInt32(OriginalData, DataPtr + 8);

            byte[] Output = new byte[OriginalSize];
            int OutputPtr = 0;

            Branch Root = BranchTable[BranchTable.Count - 1];
            Branch CurBranch = Root;

            DataPtr += 12;

            long BitCount = 0;
            while (BitCount < FileSize)
            {
                byte Mask8 = (byte)(0x80 >> (int)(BitCount % 8));

                CurBranch = BranchTable[(OriginalData[DataPtr] & Mask8) != 0 ? CurBranch.RightChild : CurBranch.LeftChild];

                if (CurBranch.LeftChild == -1)
                {
                    Output[OutputPtr++] = (byte)CurBranch.OrigByte;
                    CurBranch = Root;
                }

                BitCount++;
                if (BitCount % 8 == 0)
                    DataPtr++;
            }

            return Output;
        }
    }
}
