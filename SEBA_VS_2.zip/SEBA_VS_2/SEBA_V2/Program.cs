﻿using HuffmanEnc;
using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace SEBA_Converter
{
    class Program
    {
        static string CubeBlockData1 =
            "            <MyObjectBuilder_CubeBlock xsi:type=\"MyObjectBuilder_TextPanel\">\n" +
            "              <SubtypeName>TransparentLCDSmall</SubtypeName>\n" +
            "              <EntityId>";

        static string CubeBlockData2 =
            "</EntityId>\n" +
            "              <Min ";

        static string CubeBlockData3 =
            " />\n" +
            "              <ComponentContainer>\n" +
            "                <Components>\n" +
            "                  <ComponentData>\n" +
            "                    <TypeId>MyModStorageComponent</TypeId>\n" +
            "                    <Component xsi:type=\"MyObjectBuilder_ModStorageComponent\">\n" +
            "                      <Storage>\n" +
            "                        <dictionary>\n" +
            "                          <item>\n" +
            "                            <Key>74de02b3-27f9-4960-b1c4-27351f2b06d1</Key>\n" +
            "                            <Value>";

        static string CubeBlockData4 =
            "</Value>\n" +
            "                          </item>\n" +
            "                        </dictionary>\n" +
            "                      </Storage>\n" +
            "                    </Component>\n" +
            "                  </ComponentData>\n" +
            "                </Components>\n" +
            "              </ComponentContainer>\n" +
            "              <CustomName>Data_";

        static string CubeBlockData5 =
            "</CustomName>\n" +
            "              <ShowOnHUD>false</ShowOnHUD>\n" +
            "              <ShowInTerminal>true</ShowInTerminal>\n" +
            "              <ShowInToolbarConfig>true</ShowInToolbarConfig>\n" +
            "              <ShowInInventory>true</ShowInInventory>\n" +
            "              <Enabled>true</Enabled>\n" +
            "              <Description />\n" +
            "              <Title>Title</Title>\n" +
            "              <AccessFlag>READ_AND_WRITE_FACTION</AccessFlag>\n" +
            "              <ChangeInterval>0</ChangeInterval>\n" +
            "              <Font Type=\"MyObjectBuilder_FontDefinition\" Subtype=\"Debug\" />\n" +
            "              <FontSize>8</FontSize>\n" +
            "              <PublicDescription>Bank\n";

        static string CubeBlockData6 =
            "</PublicDescription>\n" +
            "              <PublicTitle>Public title</PublicTitle>\n" +
            "              <ShowText>NONE</ShowText>\n" +
            "              <FontColor>\n" +
            "                <PackedValue>4294967295</PackedValue>\n" +
            "                <X>255</X>\n" +
            "                <Y>255</Y>\n" +
            "                <Z>255</Z>\n" +
            "                <R>255</R>\n" +
            "                <G>255</G>\n" +
            "                <B>255</B>\n" +
            "                <A>255</A>\n" +
            "              </FontColor>\n" +
            "              <BackgroundColor>\n" +
            "                <PackedValue>4278190080</PackedValue>\n" +
            "                <X>0</X>\n" +
            "                <Y>0</Y>\n" +
            "                <Z>0</Z>\n" +
            "                <R>0</R>\n" +
            "                <G>0</G>\n" +
            "                <B>0</B>\n" +
            "                <A>255</A>\n" +
            "              </BackgroundColor>\n" +
            "              <CurrentShownTexture>0</CurrentShownTexture>\n" +
            "              <ContentType>TEXT_AND_IMAGE</ContentType>\n" +
            "              <SelectedScript />\n" +
            "              <TextPadding>0</TextPadding>\n" +
            "              <Version>1</Version>\n" +
            "              <ScriptBackgroundColor>\n" +
            "                <PackedValue>4288108544</PackedValue>\n" +
            "                <X>0</X>\n" +
            "                <Y>88</Y>\n" +
            "                <Z>151</Z>\n" +
            "                <R>0</R>\n" +
            "                <G>88</G>\n" +
            "                <B>151</B>\n" +
            "                <A>255</A>\n" +
            "              </ScriptBackgroundColor>\n" +
            "              <ScriptForegroundColor>\n" +
            "                <PackedValue>4294962611</PackedValue>\n" +
            "                <X>179</X>\n" +
            "                <Y>237</Y>\n" +
            "                <Z>255</Z>\n" +
            "                <R>179</R>\n" +
            "                <G>237</G>\n" +
            "                <B>255</B>\n" +
            "                <A>255</A>\n" +
            "              </ScriptForegroundColor>\n" +
            "              <Sprites>\n" +
            "                <Length>0</Length>\n" +
            "              </Sprites>\n" +
            "            </MyObjectBuilder_CubeBlock>\n";

        static byte[] FileBuffer;
        static byte[] ImgBin;

        static int FrameNum = 1;
        static int BankSize = 0;
        static int BankNum = 0;
        static int BlockPX = 0;
        static int BlockPY = 0;
        static int BlockPZ = 0;
        static string CustomData = "";
        static StringBuilder FinalFileData;
        static byte[] VideoDataRaw;
        static byte[] VideoDataFinal;
        static int DataPtr = 0;

        static int rgb(byte r, byte g, byte b)
        {
            return (int)(0xe100 + (r << 6) + (g << 3) + b);
        }
        static void Main(string[] args)
        {
            /*
            DirectoryInfo TargetFolder = new DirectoryInfo("D:/BadAppleProjs/SEBA/");
            if (!TargetFolder.Exists)
                return;

            var ThisProcess = Process.GetCurrentProcess();
            ThisProcess.PriorityClass = ProcessPriorityClass.High;

            foreach (FileInfo ThisFile in TargetFolder.GetFiles())
            {
                if (ThisFile.FullName.EndsWith(".bmp"))
                {
                    using (FileStream File = new FileStream(ThisFile.FullName, FileMode.Open, FileAccess.Read))
                    {
                        try
                        {
                            FileBuffer = new byte[File.Length];
                            File.Read(FileBuffer, 0, (int)File.Length);
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }

                    Console.WriteLine(ThisFile.FullName);
                    ImgBin = MyImageConverter.BitmapToBinary24(FileBuffer);
                    ImgBin = MyImageConverter.Binary24ToGray4(ImgBin);
                    //CustomData += Gray4ToRLEStr(ImgBin, (FrameNum % 2 == 1));
                    CustomData += Gray4ToRLEStr(ImgBin, true);
                    CustomData += Gray4ToRLEStr(ImgBin, false);

                    FrameNum++;

                    if (BankSize > 59200)
                    {
                        BankSize = 0;
                        FinalFileData += CubeBlockData1 + $"{123456 + BankNum}" + CubeBlockData2 + $"x=\"{BlockPX}\" y=\"{-BlockPY}\" z=\"{-BlockPZ}\"" + CubeBlockData3 + CustomData + CubeBlockData4 + $"{BankNum}" + CubeBlockData5 + $"{BankNum}" + CubeBlockData6;

                        BlockPX++;
                        if (BlockPX > 9)
                        {
                            BlockPX = 0;
                            BlockPY++;
                        }
                        if (BlockPY > 9)
                        {
                            BlockPY = 0;
                            BlockPZ++;
                        }

                        BankNum++;

                        CustomData = "";
                        Console.WriteLine($"Bank {BankNum} ------------------------");
                    }
                }
            }

            FinalFileData += CubeBlockData1 + $"{123456 + BankNum}" + CubeBlockData2 + $"x=\"{BlockPX}\" y=\"{-BlockPY}\" z=\"{-BlockPZ}\"" + CubeBlockData3 + CustomData + CubeBlockData4 + $"{BankNum}" + CubeBlockData5 + $"{BankNum}" + CubeBlockData6;
            Console.WriteLine($"Bank {BankNum + 1} ------------------------");

            System.Threading.Thread.Sleep(1000);
            ThrowFile("Result");
            return;
            */
            VideoDataRaw = new byte[67108864];

            DirectoryInfo TargetFolder = new DirectoryInfo("D:/BadAppleProjs/SEBA_HD/");
            if (!TargetFolder.Exists)
                return;

            var ThisProcess = Process.GetCurrentProcess();
            ThisProcess.PriorityClass = ProcessPriorityClass.High;

            foreach (FileInfo ThisFile in TargetFolder.GetFiles())
            {
                if (ThisFile.FullName.EndsWith(".bmp"))
                {
                    using (FileStream File = new FileStream(ThisFile.FullName, FileMode.Open, FileAccess.Read))
                    {
                        try
                        {
                            FileBuffer = new byte[File.Length];
                            File.Read(FileBuffer, 0, (int)File.Length);
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }

                    Console.WriteLine(ThisFile.FullName);
                    ImgBin = MyImageConverter.BitmapToBinary24(FileBuffer);
                    ImgBin = MyImageConverter.Binary24ToGray8(ImgBin);
                    //CustomData += Gray4ToRLEStr(ImgBin, (FrameNum % 2 == 1));
                    DataPtr += ToRLE(ImgBin, VideoDataRaw, DataPtr, true, 216);
                    DataPtr += ToRLE(ImgBin, VideoDataRaw, DataPtr, false, 216);
                }
            }

            int FinalLeng = DataPtr;
            VideoDataFinal = new byte[FinalLeng];

            DataPtr = 0;
            while (DataPtr < FinalLeng)
            {
                VideoDataFinal[DataPtr] = VideoDataRaw[DataPtr];
                DataPtr++;
            }

            byte[] VideoBytes = VideoDataFinal;
            FileStream OutputFile = new FileStream("original.txt", FileMode.Create, FileAccess.Write);
            OutputFile.Write(VideoBytes, 0, VideoBytes.Length);
            OutputFile.Close();
            OutputFile.Dispose();

            VideoBytes = Huffman.Encode(VideoBytes);
            OutputFile = new FileStream("compressed.glh", FileMode.Create, FileAccess.Write);
            OutputFile.Write(VideoBytes, 0, VideoBytes.Length);
            OutputFile.Close();
            OutputFile.Dispose();

            Console.WriteLine("To string ---------------");

            string VideoStr = ToDataStr(VideoBytes);
            OutputFile = new FileStream("compressedToString.txt", FileMode.Create, FileAccess.Write);
            byte[] StrBytes = System.Text.Encoding.Default.GetBytes(VideoStr);
            OutputFile.Write(StrBytes, 0, StrBytes.Length);
            OutputFile.Close();
            OutputFile.Dispose();

            StringBuilder VideoSB = new StringBuilder("");
            FinalFileData = new StringBuilder("");
            int i = 0;
            int LineCount = 0;
            int ColCount = 0;

            while (i < VideoBytes.Length)
            {
                VideoSB.Append(VideoBytes[i].ToString("X02"));

                ColCount++;
                if (ColCount > 124)
                {
                    VideoSB.Append("\n");

                    ColCount = 0;
                    LineCount++;
                }
                if (LineCount > 253)
                {
                    FinalFileData.Append(CubeBlockData1 + $"{123456 + BankNum}" + CubeBlockData2 + $"x=\"{BlockPX}\" y=\"{-BlockPY}\" z=\"{-BlockPZ}\"" + CubeBlockData3 + VideoSB.ToString() + CubeBlockData4 + $"{BankNum}" + CubeBlockData5 + $"{BankNum}" + CubeBlockData6);

                    VideoSB = new StringBuilder();

                    BlockPX++;
                    if (BlockPX >= 9)
                    {
                        BlockPX = 0;
                        BlockPY++;
                    }
                    if (BlockPY >= 9)
                    {
                        BlockPY = 0;
                        BlockPZ++;
                    }

                    BankNum++;

                    CustomData = "";
                    Console.WriteLine($"Bank {BankNum} ------------------------");

                    LineCount = 0;
                }
                i++;
            }

            VideoSB.Append("\n");

            FinalFileData.Append(CubeBlockData1 + $"{123456 + BankNum}" + CubeBlockData2 + $"x=\"{BlockPX}\" y=\"{-BlockPY}\" z=\"{-BlockPZ}\"" + CubeBlockData3 + VideoSB.ToString() + CubeBlockData4 + $"{BankNum}" + CubeBlockData5 + $"{BankNum}" + CubeBlockData6);

            VideoSB = new StringBuilder();

            BlockPX++;
            if (BlockPX >= 9)
            {
                BlockPX = 0;
                BlockPY++;
            }
            if (BlockPY >= 9)
            {
                BlockPY = 0;
                BlockPZ++;
            }

            BankNum++;

            CustomData = "";
            Console.WriteLine($"Bank {BankNum} ------------------------");

            ThrowFile("DataModuleCubeBlocks.xml");

            VideoBytes = Huffman.Decode(VideoBytes);
            OutputFile = new FileStream("decompressed.txt", FileMode.Create, FileAccess.Write);
            OutputFile.Write(VideoBytes, 0, VideoBytes.Length);
            OutputFile.Close();
            OutputFile.Dispose();
        }
        
        static int ToRLE(byte[] ImgData, byte[] TargetArr, int Offset, bool OddFrame = true, int ImgWidth = 160)
        {
            long PtrOrig = 0;
            int PosX = 0;

            byte CurByte = 0;
            byte ByteCount = 0;

            if (!OddFrame)
                PtrOrig += ImgWidth / 2;

            CurByte = ImgData[PtrOrig];

            byte[] Cache = new byte[ImgData.Length * 2];
            int OutputPtr = 0;

            Cache[OutputPtr++] = CurByte;

            while (PtrOrig < ImgData.Length)
            {
                PtrOrig++;
                PosX++;
                if (PosX >= ImgWidth / 2)
                {
                    PosX = 0;
                    PtrOrig += ImgWidth / 2;

                    if (PtrOrig >= ImgData.Length)
                        break;
                }

                if (CurByte != ImgData[PtrOrig] || ByteCount == 255)
                {
                    Cache[OutputPtr++] = ByteCount;
                    ByteCount = 0;
                    CurByte = ImgData[PtrOrig];
                    Cache[OutputPtr++] = CurByte;

                    continue;
                }

                ByteCount++;
            }

            Cache[OutputPtr++] = ByteCount;

            Cache[OutputPtr++] = 0x80;
            Cache[OutputPtr++] = 0x00;

            int FinalLeng = OutputPtr;

            OutputPtr = 0;
            while (OutputPtr < FinalLeng)
            {
                TargetArr[Offset + OutputPtr] = Cache[OutputPtr];
                OutputPtr++;
            }

            return OutputPtr;
        }

        static string ToDataStr(byte[] OriginalData)
        {
            int DataPtr = 0;
            StringBuilder OutputStr = new StringBuilder("");
            while (DataPtr < OriginalData.Length)
            {
                OutputStr.Append(OriginalData[DataPtr++].ToString("X02"));
                if (DataPtr % 249 == 0)
                {
                    OutputStr.Append("\n");
                }
            }
            return OutputStr.ToString();
        }

        static void ThrowFile(string Name)
        {
            FileStream OutputFile = new FileStream(Name, FileMode.Create, FileAccess.Write);
            OutputFile.Write(System.Text.Encoding.Default.GetBytes(FinalFileData.ToString()));
            OutputFile.Close();
            OutputFile.Dispose();
        }
    }
}
