﻿using System;

public class MyArrayHelper
{
    static public int ReadInt32(byte[] ByteArray, long Offset, bool BigEndian = false)
    {
        long CurrentOfs = Offset + (BigEndian ? 0 : 3);
        int OfsAdd = (BigEndian ? 1 : -1);
        int Result = 0;

        int i = 0;
        while (i < 4)
        {
            Result <<= 8;
            Result |= ByteArray[CurrentOfs];

            CurrentOfs += OfsAdd;

            i++;
        }

        return Result;
    }
}

