﻿using System;

public class MyImageConverter
{
	static public byte[] BitmapToBinary24(byte[] FileData)
    {
        if (FileData[0x1C] != 24)
        {
            Console.WriteLine("This is not 24 bit bitmap file data.");

            return null;
        }

        int Width = MyArrayHelper.ReadInt32(FileData, 0x12, false);
        int Height = MyArrayHelper.ReadInt32(FileData, 0x16, false);
        int BytesPerRow = (int)Math.Ceiling(Width*3 / 4.0)*4;

        int CurRow = Height;
        long CurPtrFile = FileData[0x0A];

        byte[] Output = new byte[Width * Height * 3];
        long CurPtrRet = Width * (Height - 1) * 3;

        while (CurRow > 0)
        {
            int PosX = 0;
            int RGBInv = 2;
            while (PosX < Width*3)
            {
                Output[CurPtrRet + PosX/3*3 + RGBInv] = FileData[CurPtrFile + PosX];

                RGBInv--;
                if (RGBInv < 0)
                    RGBInv = 2;

                PosX++;
            }

            CurRow--;
            CurPtrFile += BytesPerRow;
            CurPtrRet -= Width*3;
        }

        return Output;
    }

    static public byte[] Binary24ToGray4(byte[] Bin24Data)
    {
        byte[] Output = new byte[Bin24Data.Length / 12];
        long CurPtrRet = 0;
        long CurPtrOrig = 0;
        int Count = 0;
        byte ThisByte = 0;

        while (CurPtrOrig < Bin24Data.Length)
        {
            ThisByte <<= 2;

            int R = Bin24Data[CurPtrOrig];
            int G = Bin24Data[CurPtrOrig + 1];
            int B = Bin24Data[CurPtrOrig + 2];

            int Gray255 = (R * 38 + G * 75 + B * 15) >> 7;
            if (Gray255 > 255)
                Gray255 = 255;
            else if (Gray255 < 0)
                Gray255 = 0;

            byte Gray4 = (byte)((Gray255 / 64) & 0x03);

            ThisByte |= Gray4;

            Count++;
            if (Count > 3)
            {
                Output[CurPtrRet++] = ThisByte;
                ThisByte = 0;
                Count = 0;
            }

            CurPtrOrig += 3;
        }

        return Output;
    }

    static public byte[] Binary24ToGray8(byte[] Bin24Data)
    {
        byte[] Output = new byte[Bin24Data.Length / 6];
        long CurPtrRet = 0;
        long CurPtrOrig = 0;
        int Count = 0;
        byte ThisByte = 0;

        while (CurPtrOrig < Bin24Data.Length)
        {
            ThisByte <<= 4;

            int R = Bin24Data[CurPtrOrig];
            int G = Bin24Data[CurPtrOrig + 1];
            int B = Bin24Data[CurPtrOrig + 2];

            int Gray255 = (R * 38 + G * 75 + B * 15) >> 7;
            if (Gray255 > 255)
                Gray255 = 255;
            else if (Gray255 < 0)
                Gray255 = 0;

            byte Gray8 = (byte)((Gray255 / 32) & 0x07);

            ThisByte |= Gray8;

            Count++;
            if (Count > 1)
            {
                Output[CurPtrRet++] = ThisByte;
                ThisByte = 0;
                Count = 0;
            }

            CurPtrOrig += 3;
        }

        return Output;
    }
}
